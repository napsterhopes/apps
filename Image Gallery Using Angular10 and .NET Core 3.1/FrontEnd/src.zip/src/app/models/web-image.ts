export class WebImage
{
  webImgId : number;
	webImgName : string;
	webImgString : any;

	constructor()
	{
    this.webImgId = 0;
    this.webImgName =null;
    this.webImgString = null;
	}
}
