import { WebImage } from './web-image';

describe('WebImage', () => {
  it('should create an instance', () => {
    expect(new WebImage()).toBeTruthy();
  });
});
