import { Component, OnInit } from '@angular/core';
import { UploadFileService } from 'src/app/services/upload-file.service';
import { HttpEventType, HttpHeaderResponse } from '@angular/common/http';
import { WebImage } from '../../models/web-image';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-upload-files',
  templateUrl: './upload-files.component.html',
  styleUrls: ['./upload-files.component.css'],
})
export class UploadFilesComponent implements OnInit {
  selectedFiles: FileList;
  currentFile: File;
  progress = 0;
  message = '';
  searchData: string = '';
  filterByDateValue: string = 'Asc';
  photos: WebImage[];
  filterByDate: string[];
  showFilters: boolean = false;
  validFileExtensions = ['.jpg', '.jpeg', '.bmp', '.gif', '.png'];

  constructor(
    private uploadService: UploadFileService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    this.filterByDate = ['Asc', 'Desc'];
    this.uploadService
      .getFiles((this.searchData = ''), this.filterByDateValue)
      .subscribe(
        (response: any) => {
          this.photos = response;
          if (this.photos.length > 1) this.showFilters = true;
        },
        (err) => {
          console.error(err);
        }
      );
  }

  selectFile(event): void {
    this.selectedFiles = event.target.files;
    if (this.Validate(this.selectedFiles.item(0).name)) {
      this.upload();
    }
  }

  upload(): void {
    this.progress = 0;
    this.currentFile = this.selectedFiles.item(0);
    this.uploadService.upload(this.currentFile).subscribe(
      (event) => {
        if (event.type === HttpEventType.UploadProgress) {
          this.progress = Math.round((100 * event.loaded) / event.total);
        } else if (event instanceof HttpHeaderResponse) {
          if (event.status === 200) {
            this.message = 'Image Uploaded Successfully';
            this.uploadService
              .getFiles((this.searchData = ''), this.filterByDateValue)
              .subscribe(
                (response: any) => {
                  this.photos = response;
                  if (this.photos.length > 1) this.showFilters = true;
                },
                (err) => {
                  this.progress = 0;
                  this.message = 'Could not upload the file!';
                  this.currentFile = undefined;
                }
              );
          }
        }
      },
      (err) => {
        this.progress = 0;
        this.message = 'Could not upload the file!';
        this.currentFile = undefined;
      }
    );
    this.selectedFiles = undefined;
  }

  search() {
    if (this.searchData.length > 0) {
      if (this.photos.length < 2) {
        alert('There is only one item in the image gallery!');
        return;
      }
      this.uploadService
        .getFiles(this.searchData, this.filterByDateValue)
        .subscribe(
          (response: any) => {
            this.photos = response;
            if (this.photos.length > 1) this.showFilters = true;
          },
          (err) => {
            console.error(err);
          }
        );
    } else {
      alert('Please enter text to continue searching images');
      return;
    }
  }

  getSanitizedVal(url: string) {
    return this.sanitizer.bypassSecurityTrustUrl(url);
  }

  onFilterChange(filterValue) {
    this.uploadService
      .getFiles((this.searchData = ''), (this.filterByDateValue = filterValue))
      .subscribe(
        (response: any) => {
          this.photos = response;
          if (this.photos.length > 1) this.showFilters = true;
        },
        (err) => {
          console.error(err);
        }
      );
  }

  Validate(sFileName) {
    if (sFileName.length > 0) {
      var blnValid = false;
      for (var j = 0; j < this.validFileExtensions.length; j++) {
        var sCurExtension = this.validFileExtensions[j];
        if (
          sFileName
            .substr(
              sFileName.length - sCurExtension.length,
              sCurExtension.length
            )
            .toLowerCase() == sCurExtension.toLowerCase()
        ) {
          blnValid = true;
          break;
        }
      }

      if (!blnValid) {
        alert(
          'Sorry, ' +
            sFileName +
            ' is invalid, allowed extensions are: ' +
            this.validFileExtensions.join(', ')
        );
        this.progress = 0;
        this.message = '';
        return false;
      }
    }
    return true;
  }

  clearFilter() {
    if (this.searchData === '') {
      alert('There are no search filter applied Currently!');
      return;
    }
    this.uploadService
      .getFiles((this.searchData = ''), this.filterByDateValue)
      .subscribe(
        (response: any) => {
          this.photos = response;
          if (this.photos.length > 1) this.showFilters = true;
        },
        (err) => {
          console.error(err);
        }
      );
  }
}
