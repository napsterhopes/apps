﻿namespace Marvels.Utility
{
    public class StaticDetails
    {
        public const string SessionCart = "Cart";
        public const string Usp_GetAllCategories = "usp_GetAllCategories";
        public const string StatusSubmitted = "Submitted";
        public const string StatusApproved = "Approved";
        public const string StatusRejected = "Rejected";
        public const string Admin = "Admin";
        public const string Manager = "Manager";
    }
}
