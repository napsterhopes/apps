﻿var dataTable;

$(document).ready(
    function () {
        loadDataTable();
    })

function loadDataTable() {
    dataTable = $('#tblData').DataTable(
        {
            "ajax":
            {
                "url": "/admin/service/GetAll",
                "type": "GET",
                "datatype": "json"
            },
            "columns":
                [
                    {
                        "data": "serviceName",
                        "width": "20%"
                    },
                    {
                        "data": "category.name",
                        "width": "20%"
                    },
                    {
                        "data": "servicePrice",
                        "width": "15%"
                    },
                    {
                        "data": "frequency.frequencyCount",
                        "width": "15%"
                    },
                    {
                        "data": "id",
                        "render": function (data, type, row) {
                            var url = "service/Upsert/" + row.serviceId;
                            return '<a href=' + url + ' class="btn btn-success btn-xs text-white">Edit</a> &nbsp;<button onClick=Delete("/Admin/service/Delete/",' + row.serviceId + ') class="btn btn-primary btn-xs text-white">Delete</button>'
                        }, "width": "30%"
                    },
                ],
            "language": {
                "emptyTable": "No Records found"
            },
            "width": "100%"
        })
}

function Delete(url,id) {
    swal({
        title: "Are you sure you want to delete?",
        text: "You will not be able to restore the record!",
        icon: "warning",
        buttons: [
            'No, cancel it!',
            'Yes, I am sure!'
        ],
        dangerMode: true,
    }).then(function (isConfirm) {
        if (isConfirm) {
            $.ajax(
                {
                    type: "DELETE",
                    url: url,
                    data: { id: id },
                    success: function (data) {
                        if (data.success) {
                            swal({
                                title: 'Success!',
                                text: data.message,
                                icon: 'success'
                            }).then(function (data) {
                                dataTable.ajax.reload();
                            });
                        }
                        else {
                            swal({
                                title: 'Error!',
                                text: data.message,
                                icon: 'error'
                            });
                        }
                    }
                }
            )
        }
        else {
            swal("Cancelled", "Your record is safe :)", "error");
        }
    })
}