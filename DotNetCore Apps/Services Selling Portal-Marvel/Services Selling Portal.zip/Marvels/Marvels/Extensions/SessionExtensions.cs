﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace Marvels.Extensions
{
    //Added a custom implementation where you will convert the service list object into Json serialized object and store it in session 
    public static class SessionExtensions
    {
        public static void SetObject(this ISession session,string key,object value)
        {
            session.SetString(key, JsonConvert.SerializeObject(value));
        }

        //return default value if session has not the value for the key
        public static T GetObject<T>(this ISession session, string key)
        {
            var valueFromSession = session.GetString(key);
            return valueFromSession == null ? default(T) : JsonConvert.DeserializeObject<T>(valueFromSession);
        }
    }
}
