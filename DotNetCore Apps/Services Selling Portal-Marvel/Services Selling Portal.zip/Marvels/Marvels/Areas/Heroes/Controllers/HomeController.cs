﻿using Marvels.DataAccess.Data.Repository.IRepository;
using Marvels.Extensions;
using Marvels.Models.ViewModels;
using Marvels.Utility;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Marvels.Areas.Heroes.Controllers
{
    [Area("Heroes")]
    public class HomeController : Controller
    {
        #region Local Variables and Objects
        private readonly IUnitOfWork _unitOfWork;
        
        private HomeViewModel homeVM;
        #endregion
        public HomeController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index()
        {
            homeVM = new HomeViewModel()
            {
                CategoryList = _unitOfWork.Category.GetAll(),
                ServiceList = _unitOfWork.Service.GetAll(includeproperties:"Frequency")
            };
            return View(homeVM);
        }

        //For each Add to Cart Action store the service id in the session. 
        public IActionResult AddToCart(int serviceId)
        {
            List<int> serviceIdLst = new List<int>();
            //If Session has not been initialized yet initialize the session
            if (string.IsNullOrEmpty(HttpContext.Session.GetString(StaticDetails.SessionCart)))
            {
                //add service id to list
                serviceIdLst.Add(serviceId);
                //and add it to the session cart string key
                HttpContext.Session.SetObject(StaticDetails.SessionCart, serviceIdLst);
            }
            //If Session already exists
            else
            {
                //get the list of service Ids using the session cart string key
                serviceIdLst = HttpContext.Session.GetObject<List<int>>(StaticDetails.SessionCart);
                //if service id is not there in the list add it
                if(!serviceIdLst.Contains(serviceId))
                {
                    //add service id to list
                    serviceIdLst.Add(serviceId);
                    HttpContext.Session.SetObject(StaticDetails.SessionCart, serviceIdLst);
                }
            }
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Details(int serviceId)
        {
            var serviceFromDb = _unitOfWork.Service.GetFirstOrDefault(includeproperties:"Category,Frequency",filter : c => c.ServiceId == serviceId);
            return View(serviceFromDb);
        }
    }
}
