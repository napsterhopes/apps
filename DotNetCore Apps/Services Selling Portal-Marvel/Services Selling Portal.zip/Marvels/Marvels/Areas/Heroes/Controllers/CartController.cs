﻿using Marvels.DataAccess.Data.Repository.IRepository;
using Marvels.Extensions;
using Marvels.Models;
using Marvels.Models.ViewModels;
using Marvels.Utility;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;

namespace Marvels.Areas.Heroes.Controllers
{
    [Authorize]
    [Area("Heroes")]
    public class CartController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        [BindProperty]
        public CartViewModel CartVM { get; set; }

        public CartController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
            CartVM = new CartViewModel()
            {
                OrderHeader = new Models.OrderHeader(),
                SrvcListForCartVM = new List<Service>(),
            };
        }

        //Take the list of service IDs from the session and pass the service list
        public IActionResult Index()
        {
            if (HttpContext.Session.GetObject<List<int>>(StaticDetails.SessionCart) != null)
            {
                List<int> sessionList = new List<int>();
                sessionList = HttpContext.Session.GetObject<List<int>>(StaticDetails.SessionCart);
                foreach (var serviceId in sessionList)
                {
                    CartVM.SrvcListForCartVM.Add(_unitOfWork.Service.GetFirstOrDefault(u => u.ServiceId == serviceId, includeproperties: "Frequency,Category"));
                }
            }
            return View(CartVM);
        }

        public IActionResult Summary()
        {
            if (HttpContext.Session.GetObject<List<int>>(StaticDetails.SessionCart) != null)
            {
                List<int> sessionList = new List<int>();
                sessionList = HttpContext.Session.GetObject<List<int>>(StaticDetails.SessionCart);
                foreach (var serviceId in sessionList)
                {
                    CartVM.SrvcListForCartVM.Add(_unitOfWork.Service.GetFirstOrDefault(u => u.ServiceId == serviceId, includeproperties: "Frequency,Category"));
                }
            }
            return View(CartVM);
        }

        public IActionResult Remove(int serviceId)
        {
            if (HttpContext.Session.GetObject<List<int>>(StaticDetails.SessionCart) != null)
            {
                List<int> sessionList = new List<int>();
                sessionList = HttpContext.Session.GetObject<List<int>>(StaticDetails.SessionCart);
                sessionList.Remove(serviceId);
                HttpContext.Session.SetObject(StaticDetails.SessionCart, sessionList);
                return RedirectToAction(nameof(Index));
            }
            return View(CartVM);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Summary")]
        public IActionResult SummaryPost()
        {
            if (HttpContext.Session.GetObject<List<int>>(StaticDetails.SessionCart) != null)
            {
                _ = new List<int>();
                List<int> sessionList = HttpContext.Session.GetObject<List<int>>(StaticDetails.SessionCart);
                CartVM.SrvcListForCartVM = new List<Service>();
                foreach (var serviceId in sessionList)
                {
                    CartVM.SrvcListForCartVM.Add(_unitOfWork.Service.Get(serviceId));
                }
            }
            if (!ModelState.IsValid)
            {
                #region Check ModelState Errors
                //foreach (var modelState in ViewData.ModelState.Values)
                //{
                //    foreach (ModelError error in modelState.Errors)
                //    {
                //        string err = error.ToString();
                //    }
                //} 
                #endregion
                return View(CartVM);
            }
            else
            {
                CartVM.OrderHeader.OrderDate = DateTime.Now;
                CartVM.OrderHeader.Status = StaticDetails.StatusSubmitted;
                CartVM.OrderHeader.ServiceCount = CartVM.SrvcListForCartVM.Count;
                _unitOfWork.OrderHeader.Add(CartVM.OrderHeader);
                _unitOfWork.Save();

                foreach (var item in CartVM.SrvcListForCartVM)
                {
                    OrderDetail orderDetails = new OrderDetail
                    {
                        ServiceId = item.ServiceId,
                        OrderHeaderId = CartVM.OrderHeader.OrderHdrId,
                        ServiceName = item.ServiceName,
                        Price = item.ServicePrice
                    };

                    _unitOfWork.OrderDetails.Add(orderDetails);
                    _unitOfWork.Save();
                }
                HttpContext.Session.SetObject(StaticDetails.SessionCart, new List<int>());
                return RedirectToAction("OrderConfirmation", "Cart", new { id = CartVM.OrderHeader.OrderHdrId });
            }
        }

        public IActionResult OrderConfirmation(int id)
        {
            return View(id);
        }

    }
}
