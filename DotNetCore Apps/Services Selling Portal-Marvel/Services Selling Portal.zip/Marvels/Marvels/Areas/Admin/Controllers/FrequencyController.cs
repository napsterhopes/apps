﻿using Microsoft.AspNetCore.Authorization;
using Marvels.DataAccess.Data.Repository.IRepository;
using Microsoft.AspNetCore.Mvc;

namespace Marvels.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class FrequencyController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        public FrequencyController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index()
        {
            return View();
        }

        #region API CALLS
        [HttpGet]
        public IActionResult GetAll()
        {
            return Json(new { data = _unitOfWork.Frequency });
        }
        #endregion
    }
}
