﻿using Marvels.DataAccess.Data.Repository.IRepository;
using Marvels.Models;
using Marvels.Utility;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Marvels.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class CategoryController : Controller
    {
        private readonly DataAccess.Data.Repository.IRepository.IUnitOfWork _unitOfWork;
        public CategoryController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index()
        {
            return View();
        }

        #region Upsert
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id">Nullable to define insert or update</param>
        /// <returns></returns>
        public IActionResult Upsert(int? id)
        {
            Category objCategory = new Category();
            if(id == null)
            {
                return View(objCategory);
            }
            objCategory = _unitOfWork.Category.Get(id.GetValueOrDefault());
            if(objCategory == null)
            {
                return NotFound();
            }
            return View(objCategory);
        }
        #endregion

        #region Upsert Post
        [HttpPost]
        //Do not forger the validation for Anti forgery Token
        [ValidateAntiForgeryToken]
        public IActionResult Upsert(Category category)
        {
            if(ModelState.IsValid)
            {
                if(category.Id == 0)
                {
                    _unitOfWork.Category.Add(category);
                }
                else
                {
                    _unitOfWork.Category.Update(category);
                }
                _unitOfWork.Save();
                //using nameof to avoid spelling mistakes
                return RedirectToAction(nameof(Index));
            }
            return View(category);
        }
        #endregion

        #region API CALLS
        [HttpGet]
        public IActionResult GetAll()
        {
            //return Json(new {data = _unitOfWork.Category.GetAll()});
            return Json(new {data = _unitOfWork.SP_Call.ReturnList<Category>(StaticDetails.Usp_GetAllCategories,null)});
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var objFromDb = _unitOfWork.Category.Get(id);
            if(objFromDb == null)
            {
                return Json(new { success =false,message="Error While Deleting."});
            }
            _unitOfWork.Category.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Deleted Successfully." });
        }
        #endregion
    }
}
