﻿using Marvels.DataAccess.Data.Repository.IRepository;
using Marvels.Models.ViewModels;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using Microsoft.AspNetCore.Authorization;

namespace Marvels.Areas.Admin.Controllers
{
    [Authorize]
    [Area("Admin")]
    public class ServiceController : Controller
    {
        #region Local Variables and Objects
        private readonly IUnitOfWork _unitOfWork;
        //To Upload files to the server we will get the root path from this
        private readonly IWebHostEnvironment _hostEnvironment; 

        [BindProperty]
        public ServiceViewModel ServVM { get; set; }
        #endregion
        public ServiceController(IUnitOfWork unitOfWork,IWebHostEnvironment hostEnvironment)
        {
            _unitOfWork = unitOfWork;
            _hostEnvironment = hostEnvironment;
        }
        public IActionResult Index()
        {
            return View();
        }

        #region Upsert
        public IActionResult Upsert(int? id)
        {
            ServVM = new Models.ViewModels.ServiceViewModel()
            {
                //Create a Service Object
                Service = new Models.Service(),
                CategoryList = _unitOfWork.Category.GetCategoryListForDropDown(),
                FrequencyList = _unitOfWork.Frequency.GetFrequencyListForDropDown()
            };
            //In case it is not an insert
            if (id != null)
            {
                ServVM.Service = _unitOfWork.Service.Get(id.GetValueOrDefault());
            }
            return View(ServVM);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upsert()
        {
            if(ModelState.IsValid)
            {
                string webRootPath = _hostEnvironment.WebRootPath;
                var files = HttpContext.Request.Form.Files;
                #region Insert
                if (ServVM.Service.ServiceId == 0)
                {
                    //New Service
                    string fileName = Guid.NewGuid().ToString();
                    var uploads = Path.Combine(webRootPath, @"images\services");
                    var extension = Path.GetExtension(files[0].FileName);

                    using (var fileStreams = new FileStream(Path.Combine(uploads, fileName + extension), FileMode.Create))
                    {
                        //copy the posted image to the server
                        files[0].CopyTo(fileStreams);
                    }
                    #region SaveToDb
                    ServVM.Service.ImageUrl = Path.Combine(@"\Images\Services",fileName + extension);
                    _unitOfWork.Service.Add(ServVM.Service);
                    #endregion
                }
                #endregion
                #region Update
                else
                {
                    var serviceFromDB = _unitOfWork.Service.Get(ServVM.Service.ServiceId);
                    if (files.Count > 0)
                    {
                        //if the update has a new image uploaded
                        string fileName = Guid.NewGuid().ToString();
                        var uploads = Path.Combine(webRootPath, @"images\services");
                        var extension = Path.GetExtension(files[0].FileName);

                        //first delete the existing image from the DB for the service
                        var imagePath = Path.Combine(webRootPath, serviceFromDB.ImageUrl.TrimStart('\\'));
                        if(System.IO.File.Exists(imagePath))
                        {
                            System.IO.File.Delete(imagePath);
                        }

                        //upload the new file
                        using (var fileStreams = new FileStream(Path.Combine(uploads, fileName + extension), FileMode.Create))
                        {
                            //copy the posted image to the server
                            files[0].CopyTo(fileStreams);
                        }
                        ServVM.Service.ImageUrl = Path.Combine(@"\Images\Services", fileName + extension);
                    }
                    else
                    {
                        ServVM.Service.ImageUrl = serviceFromDB.ImageUrl;
                    }
                    _unitOfWork.Service.Update(ServVM.Service);
                }
                #endregion
                _unitOfWork.Save();
                return RedirectToAction(nameof(Index));
            }
            else
            {
                return View(ServVM);
            }
            
        }
        #endregion

        #region API Calls
        public IActionResult GetAll()
        {
            //include properties using Eager Loading will retrieve Category and Frequency based on the foreign key constraint
            return Json(new { data = _unitOfWork.Service.GetAll(includeproperties:"Category,Frequency") });
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var objFromDb = _unitOfWork.Service.Get(id);
            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Error While Deleting." });
            }
            _unitOfWork.Service.Remove(objFromDb);
            _unitOfWork.Save();
            return Json(new { success = true, message = "Service Deleted Successfully." });
        }
        #endregion
    }
}
