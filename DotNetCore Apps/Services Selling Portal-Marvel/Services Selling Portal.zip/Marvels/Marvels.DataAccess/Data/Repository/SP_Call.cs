﻿using Dapper;
using Marvels.DataAccess.Data.Repository.IRepository;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;

namespace Marvels.DataAccess.Data.Repository
{
    public class SP_Call : ISP_Call
    {
        private readonly ApplicationDbContext _db;
        public SP_Call(ApplicationDbContext db)
        {
            _db = db;
        }

        public T ExecuteReturnScaler<T>(string procedureName, DynamicParameters param = null)
        {
            using (SqlConnection sqlConn = new SqlConnection(ApplicationDbContext.GetConnectionString()))
            {
                sqlConn.Open();
                return (T)Convert.ChangeType(sqlConn.ExecuteScalar<T>(procedureName, param, commandType: System.Data.CommandType.StoredProcedure), typeof(T));
            }
        }

        public void ExecuteWithoutReturn(string procedureName, DynamicParameters param = null)
        {
            using (SqlConnection sqlConn = new SqlConnection(ApplicationDbContext.GetConnectionString()))
            {
                sqlConn.Open();
                sqlConn.Execute(procedureName, param, commandType: System.Data.CommandType.StoredProcedure);
            }
        }

        public IEnumerable<T> ReturnList<T>(string procName, DynamicParameters param = null)
        {
            using (SqlConnection sqlConn = new SqlConnection(ApplicationDbContext.GetConnectionString()))
            {
                sqlConn.Open();
                return sqlConn.Query<T>(procName, param, commandType: System.Data.CommandType.StoredProcedure);
            }
        }
        public void Dispose()
        {
            _db.Dispose();
        }
    }
}
