﻿using Marvels.DataAccess.Data.Repository.IRepository;
using Marvels.Models;
using System.Linq;

namespace Marvels.DataAccess.Data.Repository
{
    public class ServiceRepository : Repository<Service>, IServiceRepository
    {
        private readonly ApplicationDbContext _db;
        public ServiceRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public void Update(Service service)
        {
            var objFromDb = _db.Service.FirstOrDefault(s => s.ServiceId == service.ServiceId);
            objFromDb.ServiceName = service.ServiceName;
            objFromDb.ServicePrice = service.ServicePrice;
            objFromDb.LongDesc = service.LongDesc;
            objFromDb.ImageUrl = service.ImageUrl;
            objFromDb.FrequencyId = service.FrequencyId;
            objFromDb.CategoryId = service.CategoryId;

            _db.SaveChanges();
        }
    }
}
