﻿using Marvels.Models;

namespace Marvels.DataAccess.Data.Repository.IRepository
{
    public interface IOrderHeaderRepository : IRepository<OrderHeader>
    {
    }
}
