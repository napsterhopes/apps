﻿using Marvels.Models;

namespace Marvels.DataAccess.Data.Repository.IRepository
{
    public interface IOrderDetailRepository : IRepository<OrderDetail>
    {
    }
}
