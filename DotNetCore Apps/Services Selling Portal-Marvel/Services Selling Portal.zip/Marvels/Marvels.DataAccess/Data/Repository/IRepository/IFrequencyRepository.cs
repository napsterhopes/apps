﻿using Marvels.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace Marvels.DataAccess.Data.Repository.IRepository
{
    public interface IFrequencyRepository
    {
        IEnumerable<SelectListItem> GetFrequencyListForDropDown();
        void Update(Frequency frequency);
    }
}
