﻿using Marvels.Models;

namespace Marvels.DataAccess.Data.Repository.IRepository
{
    public interface IUserRepository : IRepository<ApplicationUser>
    {
        //User ID will be a Guid created by ASP NET
        void LockUser(string userId);
        void UnLockUser(string userId);
    }
}
