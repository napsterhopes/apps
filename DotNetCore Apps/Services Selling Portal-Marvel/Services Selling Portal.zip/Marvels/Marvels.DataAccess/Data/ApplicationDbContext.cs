﻿using Marvels.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Marvels.DataAccess.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        //The OnConfiguring() method allows us to select and configure the data source 
        //to be used with a context using DbContextOptionsBuilder.
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(GetConnectionString());
            }
        }

        public static string GetConnectionString()
        {
            return @"Data Source=.;Initial Catalog=DotNetCore;Integrated Security=True;Integrated Security=SSPI;";
        }

        #region entities
        //Contains the DbSet<TEntity> properties of all individual db objects type.
        public DbSet<Category> Category { get; set; } 
        public DbSet<Frequency> Frequency { get; set; }
        public DbSet<Service> Service { get; set; }
        public DbSet<OrderHeader> OrderHeader { get; set; }
        public DbSet<OrderDetail> OrderDetail { get; set; }
        public DbSet<ApplicationUser> ApplicationUser { get; set; }
        #endregion
    }
}
