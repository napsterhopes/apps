﻿namespace Marvels.DataAccess.Data.Initializer
{
    public interface IDbInitializor
    {
        void Initilaize();
    }
}
