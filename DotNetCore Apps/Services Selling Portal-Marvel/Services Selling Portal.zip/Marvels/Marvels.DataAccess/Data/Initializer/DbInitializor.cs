﻿using Marvels.Models;
using Marvels.Utility;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace Marvels.DataAccess.Data.Initializer
{
    public class DbInitializor : IDbInitializor
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public DbInitializor(ApplicationDbContext db, UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _db = db;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public void Initilaize()
        {
            #region Look for Any pending Migrations and apply them
            try
            {
                if (_db.Database.GetPendingMigrations().Count() > 0)
                {
                    _db.Database.Migrate();
                }
            }
            catch (Exception)
            {
                throw;
            }
            #endregion

            #region If any of the records exist that means data is seeded
            if (_db.Roles.Any(r => r.Name == StaticDetails.Admin))
            {
                return;
            }
            #endregion

            #region If no records exist then data needs to be seeded
            //Create Roles
            _roleManager.CreateAsync(new IdentityRole(StaticDetails.Admin)).GetAwaiter().GetResult();
            _roleManager.CreateAsync(new IdentityRole(StaticDetails.Manager)).GetAwaiter().GetResult();

            //Create User
            _userManager.CreateAsync(new IdentityUser
            {
                UserName = "admin",
                Email = "admin@gmail.com",
                EmailConfirmed = true,
                PhoneNumberConfirmed = true
            }
            //as per password req of NET
            ,"Admin123*").GetAwaiter().GetResult();

            //when user is created,assign role to it
            IdentityUser user = _db.Users.Where(v => v.Email == "admin@gmail.com").FirstOrDefault();
            _userManager.AddToRoleAsync(user, StaticDetails.Admin).GetAwaiter().GetResult();
            #endregion
        }
    }
}
