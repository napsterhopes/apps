Create Procedure usp_GetAllCategories
As
select * from Category
Go