﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Marvels.Models
{
    public class Service
    {
        [Key]
        public int ServiceId { get; set; }

        [Required]
        [Display(Name="Service Name")]
        public string ServiceName { get; set; }

        [Required]
        [Display(Name = "Service Price")]
        public int ServicePrice { get; set; }

        [Display(Name = "Service Description")]
        public string LongDesc { get; set; }

        [DataType(DataType.ImageUrl)]
        [Display(Name = "Image")]
        public string ImageUrl { get; set; }

        #region Denotes that categoryid denotes foreign key reference to category table
        [Required]
        public int CategoryId { get; set; }

        [ForeignKey("CategoryId")]
        public Category Category { get; set; }
        #endregion

        #region Denotes that frequencyid denotes foreign key reference to frequency table
        [Required]
        public int FrequencyId { get; set; }

        [ForeignKey("FrequencyId")]
        public Frequency Frequency { get; set; }
        #endregion
    }
}
