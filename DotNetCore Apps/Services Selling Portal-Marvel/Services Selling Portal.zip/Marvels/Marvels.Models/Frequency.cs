﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Marvels.Models
{
    public class Frequency
    {
        [Key]
        public int InternalFrequencyId { get; set; }

        [Required]
        [Display(Name = "Frequency Name")]
        public string FrequencyName { get; set; }

        /// <summary>
        /// How many times a year,service is needed
        /// </summary>
        [Required]
        [Display(Name = "Frequency Count")]
        public int FrequencyCount { get; set; }

    }
}
